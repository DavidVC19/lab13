package com.tecsup.petclinic.webs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tecsup.petclinic.entities.Owner;
import com.tecsup.petclinic.repositories.OwnerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class OwnerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private OwnerRepository ownerRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Owner sampleOwner;

    @BeforeEach
    void setUp() {
        ownerRepository.deleteAll();
        sampleOwner = new Owner("John", "Doe", "123 Main St", "Springfield", "123456789");
        ownerRepository.save(sampleOwner);
    }

    @Test
    void testFindAllOwners() throws Exception {
        mockMvc.perform(get("/owners"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()", is(1)))
                .andExpect(jsonPath("$[0].firstName", is(sampleOwner.getFirstName())));
    }

    @Test
    void testFindOwnerById() throws Exception {
        mockMvc.perform(get("/owners/{id}", sampleOwner.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName", is(sampleOwner.getFirstName())));
    }

    @Test
    void testCreateOwner() throws Exception {
        Owner newOwner = new Owner("Jane", "Smith", "456 Elm St", "Metropolis", "987654321");

        mockMvc.perform(post("/owners")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newOwner)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.firstName", is("Jane")));
    }

    @Test
    void testUpdateOwner() throws Exception {
        sampleOwner.setAddress("789 Oak St");

        mockMvc.perform(put("/owners/{id}", sampleOwner.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleOwner)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.address", is("789 Oak St")));
    }

    @Test
    void testDeleteOwner() throws Exception {
        mockMvc.perform(delete("/owners/{id}", sampleOwner.getId()))
                .andExpect(status().isOk());

        Optional<Owner> deletedOwner = ownerRepository.findById(sampleOwner.getId());
        assert (deletedOwner.isEmpty());
    }
}
