package com.tecsup.petclinic.exception;

/**
 * 
 * @author jgomezm
 *
 */
public class PetNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PetNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
